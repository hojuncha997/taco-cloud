package tacos.data;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import tacos.Order;

public interface OrderRepository extends CrudRepository<Order, Long> {
	
	
	//List<Order> findByDeliveryZip(String deliveryZip); 이거 건드리니까 회원가입 후 에러남.

	//Repository 구현체를 생성할 때 스프링 데이터는 해당 리퍼지터리 인터페이스에 정의된 메서드를 찾아 메서드 이름을 분석하며,
	// 저장되는 객체(여기서는 Order)의 컨텍스트에서 메서드의 용도가 무엇인지 파악한다. 본질적으로 스프링 데이터는
	//일종의 DSL(Domain Specific Language)을 정의하고 있어서 persistence에 관한 내용이 
	
	
//	Order save(Order order); JPA가 자동 생성했기 때문에 OrderController에서 orderRepo.save()를 쓸 수 있음.
}

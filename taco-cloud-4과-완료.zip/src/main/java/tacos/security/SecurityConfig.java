package tacos.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;


//이 클래스의 역할은 HTTP 요청 경로에 대한 접근 제한과 같은 보안 관련 처리를 설정해 주는 것이다.


@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
			.authorizeRequests()
			
			.antMatchers("/design", "/orders")
				.access("hasRole('ROLE_USER')")
			
			.antMatchers("/", "/**")
				.access("permitAll")
			
			.and()
				.formLogin()
					.loginPage("/login")
			.and()
				.logout()
					.logoutSuccessUrl("/")
					
			.and()
				.csrf()
				
			;
			

			
/*
			스피링 시큐리티는 /authenticate 경로의 요청으로 로그인을 처리한다. 사용자와 비밀번호 필드의 이름도 user와 pwd가 된다.
			로그인하면 해당 사용자의 로그인이 필요하다고 스프링 시큐리티가 판단했을 당시에 사용자가 머물던 페이지로 바로 이동한다.
			
			.loginProcessingUrl("/authenticate")
			.usernameParameter("user")
			.passwordParameter("pwd");
*/
			

		
/*
 			그러나 사용자가 직접 로그인 페이지로 이동했을 경우는 로그인한 후 루트 경로로 이동한다.
 			만약 이동할 페이지를 변경하고 싶다면 아래와 같이 변경할 수 있다.
 			이 경우는 사용자가 직접 로그인 페이지로 이동하고, 로그인에 성공했다면, /design 페이지로 이동한다.
 			
 			.and()
 			.formLogin()
 			.loginPage("/login")
 			.defaultSuccessUrl("/design")
  
*/	
	
		
/*
 			사용자가 로그인 전에 어떤 페이지에 있었는지와 무관하게 로그인 후에는 무조건 /design 페이지로 이동하도록 할 수 있다.
 			이 때는 defaultSuccessUrl의 두 번째 인자로 " true "를 전달하면 된다.
 			
  			.and()
  			.formLogin()
  			.loginPage("/login")
  			.defaultSuccessUrl("/design", true)
 
 */
		
		

		
		
			//  /design과 /orders의 요청은 ROLE_USER의 권한을 갖는 사용자에게만 헝요된다.
			//  이외의 요청은 모든 사용자에게 허용된다.
			//	and() 메서드는 인증 구성이 끝나서  추가적인 HTTP 구성을 적용할 준비가 됐다는 것을 나타낸다. and()는 새로운 구성을 시작할 때마다 사용 가능.
			// 	formLogin()은 커스텀 로그인 폼을 구성하기 위해 호출
			//  loginPage()에는 커스텀 로그인 페이지의 경로를 지정.
		
		
		
		//p150~ 참고
		
		
/*
		
			SpEL(Spring Expression Language)를 이용해서 유연한 설정을 할 수 있다.
			만약 화요일의 타코 생성은 ROLE_USER권한을 갖는 사용자에게만 허용하고 싶다면 아래와 같이 변형할 수 있다.
			
		http
			.authorizeRequests()
				.antMatchers("/design", "/orders")
					.access("hasRole('ROLE_USER') && " +
						"T(java.util.Calendar).getInstance().get("+
						"T(java.util.Calendar).DAY_OF_WEEK) == " +
						"T(java.util.Calendar).TUESDAY")
					.antMatchers("/", "/**").access("permitAll");
		
*/
			
		
		
		
		
		
		
		
//		.authorizeRequests()
//			.antMatchers("/design", "/orders")
//				.access("hasRole('ROLE_USER')")
//			.antMatchers("/", "/**").access("permitAll")
//		.and()
//			.httpBasic();
	}
	
	@Autowired
	private UserDetailsService userDetailsService;
	//DataSource dataSource;
	
	@Bean
	public PasswordEncoder encoder() {
		return new BCryptPasswordEncoder();
	}
	
	
	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception{
		auth
		.userDetailsService(userDetailsService)
		.passwordEncoder(encoder());
		
	
		
//		UserDetailsService를 생성하기 전에 작성한 코드.		
//			.jdbcAuthentication()
//			.dataSource(dataSource)
//			.usersByUsernameQuery("select username, password, enabled from users where username=?")
//			.authoritiesByUsernameQuery("select username, authority from authorities where username=?")
//			.passwordEncoder(new NoEncodingPasswordEncoder());
////			.passwordEncoder(new BCryptPasswordEncoder());   <== 원래는 이걸 사용해야 한다.
		
	} 
}



// 	.passwordEncoder(new BCryptPasswordEncoder());

//	이 코드를 넣어주면 로그인 팝업은 뜨지만 로그인은 되지 않는다. 사용자가 입력하는 비밀번호와 DB에 저장된 비밀번호가 달라서 그렇다.
//	DB에 저장된 비밀번호는 인코딩 되지 않았지만, 팝업창에 넣는 비밀번호는 인코딩이 되었기 때문이다.
//	따라서 여기서는 비밀번호를 암호화 하지 않는 클래스를 임시로 작성하고 사용해야 한다.













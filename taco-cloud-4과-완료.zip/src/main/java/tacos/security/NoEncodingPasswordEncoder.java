package tacos.security;

import org.springframework.security.crypto.password.PasswordEncoder;

//패스워드 입력 시 암호화 하지 않도록 만드는 클래스이다.



public class NoEncodingPasswordEncoder implements PasswordEncoder{
	
	@Override
	public String encode(CharSequence rawPwd) {
		return rawPwd.toString();
	}
	
	@Override
	public boolean matches(CharSequence rawPwd, String encodedPwd) {
		return rawPwd.toString().equals(encodedPwd);
	}

}
